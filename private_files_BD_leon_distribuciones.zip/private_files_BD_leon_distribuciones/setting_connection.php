<?php
const IP='localhost';
const DATA_BASE='BD_leon_distribuciones';

const USER_SEL='postgres';
const PASSWORD_SEL='JOSE1234';

const USER_ALL='postgres';
const PASSWORD_ALL='JOSE1234';
?>